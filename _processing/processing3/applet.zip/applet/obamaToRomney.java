import processing.core.*; 
import processing.xml.*; 

import processing.opengl.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class obamaToRomney extends PApplet {



PImage firstImage;
float counter=0;
int switchCases[]={0,0,1};



public void setup() 
{
  size(600, 600, P3D);
  firstImage= loadImage("monroe.png");
  textureMode(NORMALIZED);
  noStroke();
}

public void draw() 
{
  backgroundTranslateScaleRotate();
  texturedCubes();
  
  if(frameCount%500==0)
  switchCases[PApplet.parseInt(random(0,switchCases.length))]=PApplet.parseInt(random(0,3));
  
  
}

public void backgroundTranslateScaleRotate()
{
  background(74,197,193);
  translate(width/2 +20, height/2+20, 0);
  scale(width/20);
}


public void texturedCubes() 
{
  
  for(int x=-7;x<7;x+=2)
  for(int y=-7;y<7;y+=2)
  {
  
  pushMatrix();

  translate(x,y);
  rotateY(counter+=.0003f);
  
  for(int b=0;b<switchCases.length;b++)
  switch(switchCases[b])
  {
  case 0:rotateX(counter);break;
  case 1:rotateZ(counter);break;
  case 2:rotateY(counter);break;
  }
  
  
  
  beginShape(QUADS);
  int helper = PApplet.parseInt(firstImage.width/7.0f);
  texture(firstImage.get((x+7)*helper/2,(y+7)*helper/2,helper,helper));

  vertex(-1, -1,  1, 0, 0);
  vertex( 1, -1,  1, 1, 0);
  vertex( 1,  1,  1, 1, 1);
  vertex(-1,  1,  1, 0, 1);
  
  endShape();
  
  popMatrix();

  }
}








  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#F0F0F0", "obamaToRomney" });
  }
}
