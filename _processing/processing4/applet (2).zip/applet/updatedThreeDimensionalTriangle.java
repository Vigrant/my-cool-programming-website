import processing.core.*; 
import processing.xml.*; 

import processing.opengl.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class updatedThreeDimensionalTriangle extends PApplet {



ArrayList cubeList=new ArrayList();
int cubeSize=1;
float rotateAmount2=2*PI;
float rotateDir2=PI/4.0f;


public void setup()
{
  size(1000,300,OPENGL);
  smooth();
  noStroke();
  addCubes();
}

public void addCubes()
{
  for(int x=-65;x<65;x+=cubeSize)
  for(int z=0;z<6;z++)
  {
  cubeList.add(new Cubes(x,0,z*(-cubeSize),cubeSize,z%3));
  cubeList.add(new Cubes(x,0-cubeSize,z*(-cubeSize),cubeSize,z%3));
 
  }
}


public void draw()
{
  background(255,170,248);
  translate(width/2,height/2);
  scale(4.7f);
  drawCubes();
 }
 
 public void drawCubes()
 {
  rotateAmount2+=rotateDir2;
  rotateX(rotateAmount2/50.0f);
  for(int x=0;x<cubeList.size();x++)
  {
    ((Cubes)cubeList.get(x)).drawCube();
  }
 }
 
  

/* CLASS CUBE*/

class Cubes
{
  int xDisplacement;
  int yDisplacement;
  int zDisplacement;
  int cubeSize;
  int number;
  int rgb[]= {0,0,0};
  int rgbDir[]= {1,1,1};

  Cubes(int xDisplacement,int yDisplacement,int zDisplacement,int cubeSize,int startColor)
  {
   this.xDisplacement=xDisplacement;
   this.yDisplacement=yDisplacement;
   this.zDisplacement=zDisplacement;
   this.cubeSize=cubeSize;
   switch(startColor)
   {
   case 0: rgb[0]=100;rgb[1]=255;rgb[2]=100;break;
   case 1: rgb[0]=255;rgb[1]=100;rgb[2]=0;break;
   case 2: rgb[0]=0;rgb[1]=100;rgb[2]=255;break;
   }

   } 
  
  public void drawCube()
  {
   pushMatrix();
   translate(xDisplacement,yDisplacement+20*sin((rotateAmount2*(abs(xDisplacement)+30))/360.0f),zDisplacement);  
   fill(rgb[0],rgb[1],rgb[2],255);
   box(cubeSize); 
   popMatrix();
  }
}





  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#F0F0F0", "updatedThreeDimensionalTriangle" });
  }
}
